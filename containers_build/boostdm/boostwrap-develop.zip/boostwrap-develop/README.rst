README
======

My name is **boostwrap**. I am a Python package.

I am a wrapper of functions within the reach of `xgboost <https://github.com/dmlc/xgboost>`_ and
`scikit-learn <http://scikit-learn.org>`_ to provide an easy-to-handle regression analysis framework
based on the ensemble method known as Gradient Boosting.

Install
-------

Clone with git

.. code::

   $ git clone https://github.com/bbglab/boostwrap.git

or 

download from the `<https://github.com/bbglab/boostwrap/archive/master.zip>`_.

Move to the top folder of the repo and install with pip:

.. code::
	
   $ pip install .


Repo tree
---------

The repo has the following structure::

   |- boostwrap/
   |
   |  |- boostwrap/
   |  |  |
   |  |  |- __init__.py
   |  |  |- methods.py
   |  |  |- mutual_information.py
   |
   |- example_notebook.ipynb
   |- testing.py
   |- LICENSE
   |- MANIFEST.in
   |- README.rst
   |- requirements.txt
   |- setup.py


Usage example
-------------

The notebook `example_notebook.ipynb <http://nbviewer.jupyter.org/urls/raw.githubusercontent.com/bbglab/boostwrap/master/example_notebook.ipynb>`_
provides a standard example of usage.

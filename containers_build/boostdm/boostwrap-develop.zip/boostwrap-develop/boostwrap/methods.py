from collections import defaultdict

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.metrics import accuracy_score, matthews_corrcoef
from sklearn.metrics import explained_variance_score, mean_squared_error, r2_score

from boostwrap.mutual_information import generate_feature_ranking


COLORS = ['sandybrown', 'firebrick', 'red', 'darkseagreen', 'darkgray', 'violet', 'steelblue', 'tomato']


# TODO: write a function or a class that provides with the meta-optimization
# TODO: by doing the Bayesian optimization approach e.g. in scikit-optimize


class FeatureImportance:
    """
    Feature importance wrapper.
    It contains the importance and its standard deviation
    """

    def __init__(self, name, values, std):
        self.name = name
        self._importance = values
        self._std = std

    @property
    def importance(self):
        """Feature importance values"""
        return self._importance

    @property
    def std(self):
        """Feature importance standard deviation"""
        return self._std

    def plot(self, ax, std=True):
        """
        Make a bar plot with the feature importance

        Args:
            ax:
            std (bool): add the standard deviation to the plot or not

        """

        plot_kw = {'xerr': pd.Series(self._std)} if std else {}

        pd.Series(self._importance).plot(kind='barh',
                                                   title='Feature Importances ({})'.format(self.name),
                                                   ax=ax,
                                                   **plot_kw)

        plt.tight_layout()


class FeatureDependence:

    """Wrapper for the Features dependency data"""

    def __init__(self, name, grid, y_pred, *args, **kwargs):
        self.name = name
        self._grid = grid
        self._y_pred = y_pred

    @property
    def grid(self): return self._grid

    @property
    def y_pred(self): return self._y_pred

    def plot(self, ax, **kwargs):
        raise NotImplementedError


class CV(pd.DataFrame):

    """Wrapper on cross-validation results"""

    def plot(self, ax):
        """Make a plot with the cross-validation results"""
        x = np.array(self.index.values)
        ax.plot(x, self.iloc[:, 0].values, color='red', label='test')
        ax.plot(x, self.iloc[:, 2].values, color='blue', label='training')
        ax.set_title('Training-Test CV Error')
        ax.set_xlabel('n_estimators')
        y_label = next(iter(self.columns)).split('-')[1]
        ax.set_ylabel(y_label)
        ax.legend()
        plt.tight_layout()


class BoostingBase:
    """Base class for extreme gradient boosting classifiers and selectors"""

    def __init__(self):

        self._model = None
        self._x_data = None
        self._y_data = None

    @property
    def x_data(self): return self._x_data

    @property
    def y_data(self): return self._y_data

    @property
    def model(self): return self._model

    def train(self, x_data, y_data):
        raise NotImplementedError

    def predict(self, x_data):
        raise NotImplementedError

    def get_estimators(self):
        raise NotImplementedError

    def get_default_score(self):
        raise NotImplementedError

    @staticmethod
    def get_estimator_importance(tree, imp_type):
        """
        Args:
            tree: str: produced by method get_dump
            imp_type: str: importance type
        Returns:
            dict: for each feature id (fid) provides
                  average imp_type score of fid in tree
        """
        scores = defaultdict(list)
        # for best understanding of the following piece of code
        # consider the format given by the estimators resulting
        # from xgboost get_dump() method
        for line in tree.split('\n'):
            # look for the opening square bracket
            arr = line.split('[')
            # if no opening bracket (leaf node), ignore this line
            if len(arr) == 1:
                continue
            # look for the closing bracket, extract only info within that bracket
            fid = arr[1].split(']')
            # extract gain or cover from string after closing bracket
            g = float(fid[1].split(imp_type + '=')[1].split(',')[0])
            # extract feature name from string before closing bracket
            fid = fid[0].split('<')[0]
            scores[fid].append(g)
        return scores

    @staticmethod
    def permutation(fid, x_data):
        """
        Args:
            fid: str: feature ID
            x_data: pandas dataframe: covariate
        Returns:
            x_data with shuffled fid values
        """

        assert (fid in x_data.columns.values)
        df = x_data.copy()
        df[fid] = np.random.permutation(df[fid])
        return df

    def _permutation_importance(self, **kwargs):
        """
        Feature Importance Analysis via Permutation Test
        """
        # reference: https://medium.com/@ceshine/feature-importance-measures-for-tree-models-part-i-47f187c1a2c3
        # reference: http://parrt.cs.usfca.edu/doc/rf-importance/index.html

        main_score = self.score(self._x_data, self._y_data, **kwargs)

        permutation = {}
        permutaion_std = {}

        for c in self.x_data.columns.values:
            permuted_x_data = self.permutation(c, self._x_data)
            permutation[c] = main_score - self.score(permuted_x_data, self.y_data, **kwargs)
            permutaion_std[c] = 0
        return permutation, permutaion_std

    def get_importance(self, **kwargs):
        """
        Gets standard deviation of each feature importance by considering
        all the feature importances computed for all the estimators in the model

        reference: https://medium.com/@ceshine/feature-importance-measures-for-tree-models-part-i-47f187c1a2c3
        importance types:
            'gain': average gain of the feature when it is used in trees.
            'cover': average number of splits weighted by the number of samples concerned in each split a.k.a.
                     Gini Importance a.k.a. Mean Decrease in Impurity.
            'permutation': Permutation Importance or Mean Decrease in Accuracy
        """
        feat_imp = {}
        for imp_type in ['cover', 'gain']:
            all_feat_importances = defaultdict(list)
            for tree in self.get_estimators():
                feat_importances = self.get_estimator_importance(tree, imp_type)
                for k, v in feat_importances.items():
                    all_feat_importances[k] += v
            for k, v in all_feat_importances.items():
                q_5 = np.percentile(v, 5)
                q_95 = np.percentile(v, 95)
                v = np.array(v)
                all_feat_importances[k] = v[(v > q_5) & (v < q_95)]
            importance = {k: np.mean(np.array(v)) for k, v in all_feat_importances.items()}
            std = {k: np.std(np.array(v)) for k, v in all_feat_importances.items()}
            feat_imp[imp_type] = FeatureImportance(imp_type, importance, std)

        feat_imp['permutation'] = FeatureImportance('permutation', *self._permutation_importance(**kwargs))

        return feat_imp

    def _partial_dependence(self, feat, grid_size=50):
        raise NotImplementedError

    def get_partial_dependence(self, feat_iterable, **kwargs):
        raise NotImplementedError

    def score(self, x_data, y_data, method=None):
        raise NotImplementedError

    def cv(self, fold=5, method=None):
        raise NotImplementedError

    def plot_scatter(self, x_data, y_data, ax, **kwargs):
        """
        Make a scatter plot with the prediction results of the model against x_data

        Args:
            x_data:
            y_data:
            ax:
            **kwargs: arguments passed to matplotlib scatter method

        Returns:

        """
        y_pred = self.predict(x_data)
        ax.scatter(y_data.values, y_pred, color='green', **kwargs)
        ax.set_title('Observed-Predicted')
        ax.set_xlabel('observed')
        ax.set_ylabel('predicted')
        plt.tight_layout()

    @staticmethod
    def get_mutual_information(x_data, y_data):
        return generate_feature_ranking(x_data, y_data, beta=0.7)

    def plot_example_tree(self, ax, **kwargs):
        raise NotImplementedError


class Regressor(BoostingBase):

    class _FeatureDependence(FeatureDependence):

        def plot(self, ax, **kwargs):
            ax.plot(self._grid, self._y_pred, '-', color='green', label='fit', **kwargs)
            ax.set_title(self.name)
            ax.set_xlim(self._grid[0], self._grid[-1])
            handles, labels = ax.get_legend_handles_labels()
            ax.legend(handles, labels, loc='best', fontsize=12)

    def __init__(self, **params):

        super().__init__()
        self.__params = params
        self._model = xgb.XGBRegressor(**params)

    def train(self, x_data, y_data):
        self._x_data = x_data
        self._y_data = y_data
        params = self._model.get_params()
        n_estimators = params['n_estimators']
        xgtrain = xgb.DMatrix(self.x_data, label=self.y_data)
        self._model = xgb.train(params, xgtrain, num_boost_round=n_estimators)

    def get_estimators(self):
        trees = self._model.get_dump(with_stats=True)
        for tree in trees:
            yield tree

    def predict(self, x_data):
        assert(isinstance(x_data, pd.DataFrame))
        data = xgb.DMatrix(x_data)
        return self._model.predict(data)

    def _partial_dependence(self, feat, grid_size=50):
        x = self._x_data.copy()
        u = x[feat].values
        nan_mask = np.isnan(u)
        u[nan_mask] = np.nanmean(u)
        grid = np.linspace(np.percentile(u, 5), np.percentile(u, 95), grid_size)
        y_pred = np.zeros(len(grid))
        for i, val in enumerate(grid):
            x[feat] = val
            y_pred[i] = np.average(self.predict(x))
        return grid, y_pred

    def get_partial_dependence(self, feat_iterable, **kwargs):
        feat_dep = {}
        for feat in feat_iterable:
            grid, y_pred = self._partial_dependence(feat, **kwargs)
            feat_dep[feat] = self._FeatureDependence(feat, grid, y_pred)
        return feat_dep

    def get_default_score(self):
        return 'variance'

    def score(self, x_data, y_data, method='variance', **kwargs):
        """
        method options:
        'variance': Explained variance regression score function
        'mse': Mean squared error regression loss
        'r2': R^2 (coefficient of determination) regression score function.
        """

        assert(isinstance(x_data, pd.DataFrame))
        assert(isinstance(y_data, pd.Series))
        y_pred = self.predict(x_data)
        if method == 'variance':
            return explained_variance_score(y_data, y_pred, **kwargs)
        elif method == 'mse':
            return mean_squared_error(y_data, y_pred, **kwargs)
        elif method == 'r2':
            return r2_score(y_data, y_pred, **kwargs)

    def cv(self, fold=5, method='rmse'):
        """method option 'rmse': rooted mean square error"""

        params = {k: v for k, v in self.__params.items() if v is not None}
        xgtrain = xgb.DMatrix(self._x_data, label=self._y_data)
        return CV(xgb.cv(params,
                         xgtrain,
                         num_boost_round=params['n_estimators'],
                         metrics=method,
                         nfold=fold)
                  )

    def plot_scatter(self, ax, **kwargs):
        y_pred = self.predict(self._x_data)
        ax.scatter(self._y_data.values, y_pred, color='green', **kwargs)
        ax.set_title('Observed-Predicted')
        ax.set_xlabel('observed')
        ax.set_ylabel('predicted')
        plt.tight_layout()

    def plot_example_tree(self, ax, **kwargs):
        model = xgb.XGBRegressor(**self.__params)
        model.fit(self._x_data, self._y_data)
        xgb.plot_tree(model, **kwargs, ax=ax)


class Classifier(BoostingBase):

    class _FeatureDependence(FeatureDependence):

        def __init__(self, name, grid, y_pred, classes):
            super().__init__(name, grid, y_pred)
            self._classes = classes  # self._model.classes_

        def plot(self, ax, **kwargs):
            pred_dict = {i: list(map(lambda x: np.average(self._y_pred[i][:, x]),
                                     range(len(self._classes)))) for i, a in enumerate(self._grid)}
            for k, val in enumerate(self._classes):
                y = [pred_dict[i][k] for i, v in enumerate(self._grid)]
                ax.plot(self._grid, y, '-', color=COLORS[k], label=str(val), **kwargs)
            ax.set_title(self.name)
            handles, labels = ax.get_legend_handles_labels()
            ax.legend(handles, labels, loc='best', fontsize=12)

    def __init__(self, **params):

        super().__init__()
        self._model = xgb.XGBClassifier(**params)

    def train(self, x_data, y_data, **kwargs):
        self._x_data = x_data
        self._y_data = y_data
        self._model.fit(self.x_data, self.y_data, **kwargs)

    def predict(self, x_data):

        assert(isinstance(x_data, pd.DataFrame))
        return self._model.predict(x_data)

    def predict_proba(self, x_data):

        assert(isinstance(x_data, pd.DataFrame))
        return self._model.predict_proba(x_data)

    def _partial_dependence(self, feat, grid_size=50):

        x = self._x_data.copy()
        u = x[feat].values
        nan_mask = np.isnan(u)
        u[nan_mask] = np.nanmean(u)
        grid = np.linspace(np.percentile(u, 5), np.percentile(u, 95), grid_size)
        y_pred = {}
        for i, val in enumerate(grid):
            x[feat] = val
            y_pred[i] = self.predict_proba(x)
        return grid, y_pred

    def get_partial_dependence(self, feat_iterable, **kwargs):
        feat_dep = {}
        for feat in feat_iterable:
            grid, y_pred = self._partial_dependence(feat, **kwargs)
            feat_dep[feat] = self._FeatureDependence(feat, grid, y_pred, self._model.classes_)
        return feat_dep

    def get_estimators(self):

        trees = self._model.get_booster().get_dump(with_stats=True)
        for tree in trees:
            yield tree

    def get_default_score(self):
        return 'accuracy'

    def score(self, x_data, y_data, method='accuracy', thresh=0.5, **kwargs):
        """method options: 'accuracy', 'matthews'"""

        assert(isinstance(x_data, pd.DataFrame))
        assert(isinstance(y_data, pd.Series))
        y_pred = self.predict_proba(x_data)[:, 1]
        y_pred = np.array(list(map(lambda x: int(x >= thresh), y_pred)))
        if method == 'accuracy':
            return accuracy_score(y_data, y_pred, **kwargs)
        elif method == 'matthews':
            return matthews_corrcoef(y_data, y_pred, **kwargs)

    def cv(self, fold=2, method=(), feval=None):
        # TODO: Something is not working correctly, check it out
        params = {k: v for k, v in self._model.get_params().items() if v is not None}
        params['num_class'] = len(self._model.classes_)
        xgtrain = xgb.DMatrix(self._x_data, label=self._y_data)
        return CV(xgb.cv(params,
                         xgtrain,
                         num_boost_round=params['n_estimators'],
                         metrics=method,
                         feval=feval,
                         nfold=fold)
                  )

    def plot_example_tree(self, ax, **kwargs):
        model = self._model
        xgb.plot_tree(model, **kwargs, ax=ax)

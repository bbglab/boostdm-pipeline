from os import path
from setuptools import setup, find_packages


VERSION = "0.1"


directory = path.dirname(path.abspath(__file__))
with open(path.join(directory, 'requirements.txt')) as f:
    required = f.read().splitlines()


# Get the long description from the README file
with open(path.join(directory, 'README.rst'), encoding='utf-8') as f:
    long_description = f.read()


setup(
    name='boostwrap',
    version=VERSION,
    description='Gradient Boosting wrapper',
    long_description=long_description,
    long_description_content_type='text/x-rst',
    packages=find_packages(),
    author='Ferran Muiños',
    author_email='ferran.muinos@irbbarcelona.org',
    install_requires=required,
    license='GNU GPLv3',
    url='https://github.com/bbglab/boostwrap',
)
